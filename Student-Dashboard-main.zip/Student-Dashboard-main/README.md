# Student-Dashboard
A minimal, responsive and dynamic Student Dashboard  project made up using HTML, CSS &amp; JavaScript 

![dashboard](https://user-images.githubusercontent.com/63731449/205628267-fdb8f7e9-f8df-42a4-b0f0-ef81c2e1c577.png)
